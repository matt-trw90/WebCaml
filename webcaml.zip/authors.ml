let hours_worked = 120
